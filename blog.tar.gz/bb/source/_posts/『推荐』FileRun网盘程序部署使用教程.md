---
title: 『推荐』FileRun网盘程序部署使用教程
tags:
  - 教程资源
  - 网盘资源
  - FileRun
  - filerun.com
  - FileRun文件管理
  - FileRun网盘
  - 网盘部署
  - 部署教程
date: 2017-09-15 16:00:58
---

![『推荐』Filerun网盘程序部署使用教程](https://ws1.sinaimg.cn/large/7efa749fly1fja7tv1b2oj20c403m3yd.jpg)

&nbsp;

网上说 FileRun 是世界上最好的文件网盘程序了？ 最近尝试了一下，感觉还真不错~

整体的UI极其美观，插件支持也非常强大。

&nbsp;

## 官方网址

[http://www.filerun.com](/go/index.html?u=http://www.filerun.com)

&nbsp;

## 免费/商业版

FileRun 分免费版和商业版。对于个人来说，免费版足矣~~

详细的区别见下表格：

<table class="table">
<thead>
<tr>
<th>功能/服务</th>
<th>免费版</th>
<th>商业版</th>
</tr>
</thead>
<tbody>
<tr>
<td><span style="color: #ff0000;">用户数量</span></td>
<td>3</td>
<td>无限</td>
</tr>
<tr>
<td>软件更新</td>
<td>_✅_</td>
<td>_✅_</td>
</tr>
<tr>
<td>技术支持服务</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>免费安装服务</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>免费服务器配置服务</td>
<td></td>
<td>20多个用户许可证</td>
</tr>
<tr>
<td>免费手机应用</td>
<td>_✅_</td>
<td>_✅_</td>
</tr>
<tr>
<td>免费桌面同步应用程序</td>
<td>_✅_</td>
<td>_✅_</td>
</tr>
<tr>
<td>OAuth2 API</td>
<td>_✅_</td>
<td>_✅_</td>
</tr>
<tr>
<td>WebDAV访问</td>
<td>_✅_</td>
<td>_✅_</td>
</tr>
<tr>
<td>Mozilla Thunderbird FileLink插件</td>
<td>_✅_</td>
<td>_✅_</td>
</tr>
<tr>
<td>SMTP电子邮件连接</td>
<td>_✅_</td>
<td>_✅_</td>
</tr>
<tr>
<td>与链接分享</td>
<td>无限</td>
<td>无限</td>
</tr>
<tr>
<td>文件请求</td>
<td>无限</td>
<td>无限</td>
</tr>
<tr>
<td>与用户分享</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>用户活动Feed</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>每个文件活动日志</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>文件锁定

（用户可以锁定文件，以便其他用户不对其进行更改。）</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>启用每个文件夹通知

（选择您希望接收通知的文件夹。）</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>允许用户编辑他们正在发送文件的电子邮件地址。</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>全文文件索引和搜索

（允许文件按内容搜索）</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>Pusher.com集成

（用于实时通知）</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>用户注册过程

（通过电子邮件帐户验证）</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>验证集成

（WordPress，Joomla，Drupal等）</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>LDAP身份验证

（包括对Active Directory联盟的支持）</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>SAML / Shibboleth认证</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>双因素认证</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>密码策略经理</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>导入用户记录

（从CSV文件，映射字段）</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>导出用户记录

（到CSV文件）</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>管理员用户</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>用户角色和组</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>文件空间配额</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>账户到期日</td>
<td></td>
<td>_✅_</td>
</tr>
<tr>
<td>没有“FileRun”</td>
<td></td>
<td>_✅_</td>
</tr>
</tbody>
</table>

&nbsp;

## 演示地址

博主演示：https://filerun.somecolor.cc?username=ruyo&amp;password=ruyo

用户名/密码：ruyo/ruyo

&nbsp;

官方演示：https://demo.filerun.co

用户名/密码： admin/admin（download/download）（upload/upload）

&nbsp;

## 安装部署

### 系统环境

Apache2.4 + PHP7.0 + MySql5.6

需要扩展 ionCube 、 imagemagick

&nbsp;

安装环境太复杂？这里有好多面板也有一键安装脚本~

[#收集控#国内外VPS主机管理面板和一键安装脚本](http://51.ruyo.net/p/5322.html)

&nbsp;

### 搭建网站

博主使用的是CentOS6 X64 系统部署。

1）环境搭建好以后，下载源码安装。

可以将zip文件下载到本地然后上传到服务器。也可以在网站目录执行以下命令。
<pre class="crayon-plain-tag">wget ftp://192.99.11.204/FileRun_2017_03_18_PHP7.zip 
unzip FileRun_2017_03_18_PHP7.zip</pre>

2）修改目录权限。
<pre class="crayon-plain-tag">chmod 777 -R system/data</pre>

&nbsp;

3）访问网址，FileRun提供向导。

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjcb13vglfj20k90ee3zk.jpg)

&nbsp;

&nbsp;

4）检查运行环境。

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjcb143ueej20gs0cjdgu.jpg)

&nbsp;

5）设置数据库信息。

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjcb14a47dj20bw0c7750.jpg)

&nbsp;

6）安装成功，分配一个超级用户名和密码。

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjcb14itgoj20co0bomxx.jpg)

&nbsp;

7）第一次登陆系统最好将默认的密码修改一下。

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjcb14qssbj20d40d6dgj.jpg)

&nbsp;

## 环境设置

### 软件授权

安装后会给一个本地的授权。当然可以升级成在线授权。

访问 【Control Panel】 -&gt;  【Software licensing】

点击 【更新】 然后填写邮箱。

FileRun 会发一封邮件，里面有授权的 licensing key 还有一个邮箱，邮箱密码。

邮箱密码有啥用？

可以登录 [http://www.filerun.com/client-area](/go/index.html?u=http://www.filerun.com/client-area) 查看自己授权情况。

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjcb14xkccj20mf0cy3zc.jpg)

当然还有其他作用，后面会提到~~~

&nbsp;

### 界面汉化

访问 【Control Panel】 -&gt;  【Interface options】可以设置语言。

虽然支持中文，但是严重怀疑是不是中国人给汉化的。看的我一脸懵逼~~~

辛亏 FileRun 提供了翻译方法，有时间的兄弟可以去完善一下~~~

翻译地址：[http://www.filerun.com/client-area/?module=tools&amp;section=translate](/go/index.html?u=http://www.filerun.com/client-area/?module=tools&amp;section=translate)

_PS：无法登陆？看软件授权部分说明。_

截止我发布本文，中文汉化程度 64% 。但是翻译的太TM挫了~~~

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjcbqp1fj5j20cx0ei3ze.jpg)

&nbsp;

### EMAIL设置

访问 【Control Panel】 -&gt;  【E-mail】设置。

可以设置SMTP发信，以及邮件通知模板。

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjfnd4owg1j20e70hmtaa.jpg)

&nbsp;

也可以制定邮件通知规则。查看邮件历史。

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjfnb34c3jj20cq0ayt95.jpg)

&nbsp;

&nbsp;

### 图片预览设置

图片预览需要，服务器安装 ImageMagick，FFmpeg插件。

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjfnw186u5j20gw0as3ze.jpg)

&nbsp;

**ImageMagick安装了，但是路径找不到？**

使用命令：whereis imagemagick 看下安装目录。

如图：

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjfo0i8izpj20gq09wdgs.jpg)

&nbsp;

**FFmpeg插件如何安装？**

CentOS可以执行以下代码，直接安装~
<pre class="crayon-plain-tag">yum install yasm -y
wget http://ffmpeg.org/releases/ffmpeg-3.1.3.tar.bz2
tar jxvf ffmpeg-3.1.3.tar.bz2
cd ffmpeg-3.1.3
./configure
make &amp;&amp; make install</pre>

&nbsp;

### 插件管理设置

FileRun集成了很多插件，基本涵盖了日常使用的功能。灰常强大~

![](https://ws3.sinaimg.cn/mw690/7efa749fly1fjfobvxd5gj20er0inwg0.jpg)

&nbsp;

## API操作

首先站点需要开启SSL。然后 访问 【Control Panel】 -&gt;  【API】中 Enable API 开启。

具体API说明，请参考：http://docs.filerun.com/api

&nbsp;

## 马甲评价

这套程序是非常强大的，功能很多。所以显得有些过于庞大。

此网盘程序不支持匿名访问，有点不太爽。

&nbsp;

&nbsp;