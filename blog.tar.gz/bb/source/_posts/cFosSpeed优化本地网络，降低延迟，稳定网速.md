---
title: cFosSpeed优化本地网络，降低延迟，稳定网速
tags:
  - 教程资源
  - 系统相关
  - cFosSpeed
  - cFosSpeed使用教程
  - cFosSpeed破解版
  - 网络加速器
date: 2017-09-14 04:07:32
---

![cFosSpeed优化本地网络，降低延迟，稳定网速](https://ws1.sinaimg.cn/large/7efa749fly1fjixbqvbykj20by04iq3j.jpg)

&nbsp;

## 简介

**cFosSpeed** 是一款由德意志著名 cFos 开发商专注设计与制作出品的可以在 Windows 操作系统上管理网络流量的网络优化加速器。

该软件以驱动程序的方式附加于当前系统环境并进行数据包监测与应用层协议的分析。cFosSpeed 可以使得用户最大程度地利用当前带宽，因此，较获得在线游戏玩家与网络电话用户的青睐。

&nbsp;

## 官网

[http://www.cfos.de/zh-cn/index.htm](/go/index.html?u=http://www.cfos.de/zh-cn/index.htm)

&nbsp;

## 功能

**cFosSpeed 加快数据吞吐速率，降低网络延时。**

*   让您在高速上传下载时仍然保持网络的快速
*   改善您的网络游戏延时
*   减少音视频缓冲问题
*   **Wi-Fi 基地台**

    將 cFos 流量塑型用於智慧型手機、平板電腦與其他行動裝置。

cFosSpeed 通过**Traffic Shaping流量整形 和 优化技术**来改善您的网络连接。

**适用的网络接入类型**: DSL, Cable,无线宽带(2G/3G), Wi-Fi等等。

&nbsp;

<div class="well">有部分没用过的人可能把这个软件看成是一个类似网游加速器的软件，那么在此说明一下，这个软件并不能起到那种网游加速器的改善效果，如果自身的网络从根本上就很差，那么不会有很大的改变。如玩游戏时，自身网络是铁通的，玩游戏经常丢包严重，或者自身是联通的玩电信区的游戏，出现的高ping，这些情况都不会在使用这个软件上获得改变。总的来说，这个软件改善的是自己这端的网络环境，而不能改变运营商提供的真实网络环境。本身网络好，用起来会更好，本身网络不好，用起来效果会次一些。</div>

## 软件下载

该软件非免费使用。支持正版软件请到官网下载~

https://www.cfos.de/zh-cn/download/download.htm?__ntrack_pv=1

目前官方活动价格是22元左右~（活动即将结束）

也可以上万能的淘宝购买~

&nbsp;

破解版（该版本来自吾爱破解，自行斟酌安装~）：

https://pan.baidu.com/s/1mhBC7Ja

&nbsp;

## 适用系统

支持Windows 10 / 8.1 / 8 / 7

&nbsp;

&nbsp;

&nbsp;

## 工作原理

<span style="font-family: 'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;"><span style="color: #555555;">普通数据传输：</span></span>数据需要被确认接收（ACK）之后新数据才能发送。

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixh0se6zg205u028q37.gif)

&nbsp;

<span style="font-family: 'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;"><span style="color: #555555;">无流量塑形时：</span></span>当有数据上传时，数据接收确认（ACK）停顿，从而造成下载速度放慢。

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixhywnlng205u028wgx.gif)

&nbsp;

<span style="font-family: 'Microsoft Yahei', 'Helvetica Neue', Helvetica, Arial, sans-serif;"><span style="color: #555555;">cFos 流量塑形：</span></span>数据接收确认（ACK）在上传时被划定优先级，从而允许下载以最大速度进行。

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixim2zucg205u028756.gif)

&nbsp;

## 使用场景

对于经常使用迅雷等 P2P 工具下载的用户来说，cFosSpeed 可以让您在满速下载的同时正常浏览网页，以前网页卡卡的情况再也不会让你烦恼。

对于经常玩网游的用户来说，cFosSpeed 可以让你享受满速低 PING。cFosSpeed 是华硕、技嘉、华擎和微星等电竞游戏主板的官方网络加速器。

对于经常使用 VoIP 网络电话（如：Skype）的用户来说，cFosSpeed 可以通过提高其优先级让您获得更好的通话质量。

对于其他的浏览器或下载工具，比如：Firefox、IE、Chrome、IDM、FDM 等等，cFosSpeed 也可以让你获得更快的下载速度。

&nbsp;

## 使用指南

在cFosSpeed网站中有教程，右键cFosSpeed图标，菜单栏里有个速度向导，点击即可进入链接，大家可以参照着速度向导的方法去设置。

**速度向导的链接：**

以下为按官网速度向导教程下使用中文界面的设置过程，使用的软件版本号为10.20.2282。

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixpf75t5j206j0bgglo.jpg)

&nbsp;

&nbsp;

**首先调整cFosSpeed到最佳**

⦁ 右键点击位于任务栏处的cFosSpeed图标，点击“流量调整”&gt;“线路校准”

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixptcoivj20ck0bjgoj.jpg)

&nbsp;

然后等待2-3分钟，直到状态窗口上显示没有或者几乎没有流量动静时为止

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixqhlok7j208904dgn5.jpg)

&nbsp;

满速下载，至少保持20秒，测试完了后，再满速上传，保持 1-2 分钟，然后重复 2-3 次。

打开”选项&gt;设置“

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixr3m0jaj20aq0bm418.jpg)

&nbsp;

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixrdy3b7j20fe0fead8.jpg)

&nbsp;

在此处查看自己的校准度~

&nbsp;

打开控制台我们将会看到传统的命令行界面，键入<pre class="crayon-plain-tag">spd speed</pre> 查看参数面板

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixs8w2fpj20fe0bgjse.jpg)

&nbsp;
<pre class="crayon-plain-tag">maxtxraw：最大上传速度总值
maxtxacked：最大上传速度ACK字元值
maxrx：最大下载速度
burst_cnt：爆发的链接项数
txspeed：上传速度值
tx_bounce_cnt：TX的弹射链接项
calibrated：校准度</pre>

无法百分百的用户，那么可以尝试进行手动设置。

<pre class="crayon-plain-tag">spd set maxtxraw ****</pre> 键入你们的上传速度总值

<pre class="crayon-plain-tag">spd set maxtxacked ****</pre> 键入你们的上传速度ACK字元值，常与上传速度接近

<pre class="crayon-plain-tag">spd set maxrx ****</pre> 键入你们的最大下载速度值

<pre class="crayon-plain-tag">spd set txspeed ****</pre> 键入你们的上传速度值

<pre class="crayon-plain-tag">spd set burst_cnt ****</pre> 键入爆发的连接项 算法为左边的ping 减去 pong ，因为ping与pong时常变化，所以取一个接近的值就好

<pre class="crayon-plain-tag">spd set tx_bounce_cnt 5</pre> 设置TX的弹射连接项，默认为5，5值也为不确定的意思，所表示的意思为你的宽带接上网络之后，还要经过多少的服务器机房的转接才能到达总服务器，部分按速度向导设置后达到百分百的用户为0，则你们连接上去会很快，不需要转接。

&nbsp;

_PS：不知道自己上传下载速度数值的，可以借用其他测速工具来获取，测速过程尽量避免其他程序占用网络。_

参数都按你们开通的宽带的值设置好之后，你们便开启满载的下载速度去下载一个大文件做测试，看看ping是否还是保持很低，ping值显示于窗口的白色字部分。

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixvfxl4ej206y06hgll.jpg)

有的用户可能会出现，满载下载时ping还在一百多甚至更多的情况，这时候你们就需要强制更改线路，这是这个软件一个很强大的功能。

&nbsp;

在控制台窗口键入<pre class="crayon-plain-tag">spd pingstat</pre> 键入后，如下：

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixvvecg6j20fe0cmmz0.jpg)

&nbsp;

<pre class="crayon-plain-tag">RTT</pre>是往返时间，即延迟；

<pre class="crayon-plain-tag">UDP</pre>是不可靠的传输连接，但是速度非常快，适合用来下载东西；

<pre class="crayon-plain-tag">ICMP</pre>是internet content message protocol,因特网文本信息控制协议，它决定了信息是否能可靠的传输，工作与网络层，是TCP/IP协议的核心，必须依靠它。

平时喜欢玩游戏的可以选icmp的线路，对下载多的可以选udp的线路试试。

更改线路命令，键入：<pre class="crayon-plain-tag">spd pinger +（线路名称）</pre>，例：s<pre class="crayon-plain-tag">pd pinger icmp_km5</pre>。

键入后需要锁定，以免几分钟后运营商的服务器机房将其重置回原来默认的线路。

锁定线路键入：<pre class="crayon-plain-tag">spd gset ping_fixed 1</pre>

_PS：锁定只可一次，永久锁定在锁定命令后面加 &#8211; save，永久锁定不推荐，因为运营商每次给的线路可能会不一样 。_

&nbsp;

## 优化代理

cFosSpeed还支持优化V~P~N的连接，我们需要打开程序的按着目录，由于软件的文件夹是隐藏的，我们需要在计算机选择显示隐藏文件夹，然后打开文件<pre class="crayon-plain-tag">global</pre>

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixzde2rej20fe09d40q.jpg)

&nbsp;

在<pre class="crayon-plain-tag">global</pre>文件中的[parm]下加一行<pre class="crayon-plain-tag">ping_dest=*.*.*.*</pre>。<pre class="crayon-plain-tag">*.*.*.*</pre>为自己使用的V~P~N的IP地址。

![](https://ws1.sinaimg.cn/large/7efa749fly1fjixzuj3ddj20er0fqt9a.jpg)

&nbsp;

校准完成后测试一下，看看自己是否可以在下载时，玩游戏是否保持着低ping。

&nbsp;

同样道理，使用SSTap也是可以这样优化哦~~

[_SSTap_支持SS/SSR全局代理，配置简单，愉快的玩游戏](http://51.ruyo.net/p/4400.html)

&nbsp;

&nbsp;

_参考文章：_

_[http://www.nruan.com/47173.html](http://www.nruan.com/47173.html)_

_[https://www.52pojie.cn/thread-641304-1-1.html](https://www.52pojie.cn/thread-641304-1-1.html)_

&nbsp;