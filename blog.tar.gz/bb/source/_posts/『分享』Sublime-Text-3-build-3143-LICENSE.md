---
title: 『分享』Sublime Text 3 build 3143 LICENSE
tags:
  - 开发软件
  - Sublime Text
  - Sublime Text 3 build 3143 注册码
  - Sublime Text 3注册码
  - 注册码
date: 2017-09-14 06:30:00
---

![『分享』Sublime Text 3 build 3143 LICENSE](https://wx4.sinaimg.cn/mw690/7efa749fly1fjj2gpumqgj20yj0ms79b.jpg)

Sublime Text 是受众多开发者比较喜欢的代码编辑器。支持全系统平台。

今天 Sublime Text官网，Logo，编辑器UI 都变啦~ 漂亮了不少~

网上有人分享了一组最新版 Sublime Text 3（3143） 的正版注册码。

有需要的速速激活啦~~~
<pre class="crayon-plain-tag">—– BEGIN LICENSE —–
TwitterInc
200 User License
EA7E-890007
1D77F72E 390CDD93 4DCBA022 FAF60790
61AA12C0 A37081C5 D0316412 4584D136
94D7F7D4 95BC8C1C 527DA828 560BB037
D1EDDD8C AE7B379F 50C9D69D B35179EF
2FE898C4 8E4277A8 555CE714 E1FB0E43
D5D52613 C3D12E98 BC49967F 7652EED2
9D2D2E61 67610860 6D338B72 5CF95C69
E36B85CC 84991F19 7575D828 470A92AB
—— END LICENSE ——</pre>

![](https://wx4.sinaimg.cn/mw690/7efa749fly1fjj2plmuycj20fs09ndgj.jpg)

&nbsp;

![](https://wx4.sinaimg.cn/mw690/7efa749fly1fjj2plqed8j209704xwel.jpg)

&nbsp;

&nbsp;

&nbsp;

&nbsp;

_资源来自：_

_[http://www.hostloc.com/thread-388822-1-1.html](http://www.hostloc.com/thread-388822-1-1.html)_

_[https://gist.github.com/jochemstoel/29205b69712924c7ba8d3f83b6dd0dd9](https://gist.github.com/jochemstoel/29205b69712924c7ba8d3f83b6dd0dd9)_

&nbsp;

&nbsp;