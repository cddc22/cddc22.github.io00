---
title: 『更新』eBesucher挂机赚欧元教程指南（含羊毛）
tags:
  - 教程资源
  - eBesucher
  - eBesucher挂机教程
  - eBesucher脚本
  - 挂机赚欧元
date: 2017-09-13 10:00:53
---

![eBesucher挂机赚欧元教程指南（含羊毛）](https://wx4.sinaimg.cn/mw690/7efa749fly1fji1y3cy1ij20rl0e076m.jpg)

&nbsp;

<span style="color: #ff0000;">2017年9月14日17:29:47 更新：新增CentOS6 X64 挂机脚本。</span>

&nbsp;

eBesucher是德国目前最著名的自动冲浪赚钱站，该站最低提现金额PAYPAL2欧元，此站除了可以通过自动冲浪来赚钱之外，还可以通过邮件交换的方式来赚钱。

和我们之前介绍的《[_Vagex_开放注册了,开始网赚之路](http://51.ruyo.net/p/2792.html)》有所不同。这家是欧元支付，只要挂一些网页的访问量。

&nbsp;

## 注册地址

[http://www.ebesucher.com/](/go/index.html?d=aHR0cDovL3d3dy5lYmVzdWNoZXIuY29tLz9yZWY9bWFsYW9odQ==)   (该链接含AFF特效加持)

&nbsp;

## 如何挂机

### 火狐插件

比较推荐这种方式。目前要求火狐的版本高于31且小于54。

推荐使用 pcxFirefox，优点不需要安装，不担心火狐自动升级了。

[https://sourceforge.net/projects/pcxfirefox/files/Release/Firefox/](/go/index.html?u=https://sourceforge.net/projects/pcxfirefox/files/Release/Firefox/)

火狐安装成功后，访问：[https://www.ebesucher.com/data/firefoxaddon/latest.xpi](/go/index.html?u=https://www.ebesucher.com/data/firefoxaddon/latest.xpi) 安装最新版的EB插件。

![](https://ws1.sinaimg.cn/large/7efa749fgy1fjhs52jvwrj20bi082q40.jpg)

插件安装成功，右上角可见图标。点击↓箭头填写用户。即可挂机了~~~

![](https://ws1.sinaimg.cn/mw690/7efa749fgy1fjhs3003n3j20ks08kta9.jpg)

&nbsp;

&nbsp;

### 网页挂机

登录后可以直接点击【SURF NOW】,开始挂机~~

![](https://wx4.sinaimg.cn/mw690/7efa749fly1fji1p38x36j20dl0homxv.jpg)

&nbsp;

## 脚本挂机

主要是利用Linux系统安装vnc实现。以下的一键叫均可以实现挂机。

<div class="alert alert-success">提醒：挂机脚本非刷量的脚本，而是一键安装然后启动挂机。非作弊！！！！</div>

&nbsp;

### CentOS 6 X64

这里整理了一下 CentOS 6安装VNC和火狐实现挂机。

其实就是将之前的代码整理了一下，[Vagex开放注册了,开始网赚之路](http://51.ruyo.net/p/2792.html#7)。

主要代码：
<pre class="crayon-plain-tag">yum -y install expect tigervnc tigervnc-server
wget https://download.Fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm 
rpm -ivh epel-release-6-8.noarch.rpm 
yum search xfce 
yum groupinfo xfce 
yum groupinstall xfce chinese-support -y
yum -y install firefox
wget ftp://192.99.11.204/ebesucher/install_flash_player_11_linux.x86_64.tar.gz
tar zxvf install_flash_player_11_linux.x86_64.tar.gz
mkdir -p ~/.mozilla/plugins/
cp libflashplayer.so ~/.mozilla/plugins/
echo 'VNCSERVERS="1:root"
VNCSERVERARGS[1]="-geometry 1024x1024 "' &gt;&gt; /etc/sysconfig/vncservers
wget ftp://192.99.11.204/ebesucher/setpwd_centos6.sh
chmod 777 setpwd_centos6.sh
./setpwd_centos6.sh
dbus-uuidgen &gt; /var/lib/dbus/machine-id</pre>

一键安装脚本（执行此脚本上面的代码就不用执行。将下面的 malaohu 替换成你的用户名！！！！！）：

<span style="color: #ff0000;">特别提醒：这个脚本只适合 CentOS6 X64 系统！！！！！</span>
<pre class="crayon-plain-tag">wget ftp://192.99.11.204/ebesucher/install_centos6.sh &amp;&amp; chmod 777 install_centos6.sh &amp;&amp; ./install_centos6.sh; firefox --display=localhost:1.0 --new-tab http://www.ebesucher.com/surfbar/malaohu &gt;/dev/null 2&gt;&amp;1 &amp;</pre>

&nbsp;

### Debian7 X64

这里我们主要说一下 Debian7系统安装 vncserver 。

这部分内容主要参考自：[https://moeclub.org/2017/09/12/388/](https://moeclub.org/2017/09/12/388/)

不同的是我们演示的是 Debian 7 X64系统，博主整理了一份一键安装脚本。

环境安装（如果嫌麻烦，博主整理了一个脚本文件，直接执行往下看）：
<pre class="crayon-plain-tag">#!/bin/sh
apt-get update
apt-get install -y expect xorg lxde-core tightvncserver firefox-esr
mkdir -p ~/.vnc
cat&gt;~/.vnc/xstartup&lt;&lt;EOF
#!/bin/sh
xrdb $HOME/.Xresources
xsetroot -solid black

EOF
mkdir -p /usr/lib/mozilla/plugins
cd /usr/lib/mozilla/plugins
wget ftp://192.99.11.204/ebesucher/flash_player_npapi_linux.x86_64.tar.gz |tar -zx libflashplayer.so
cd ~/
wget ftp://192.99.11.204/ebesucher/setpwd1.sh
chmod 777 setpwd1.sh
./setpwd1.sh</pre>

&nbsp;

一键安装脚本（执行此脚本上面的代码就不用执行。将下面的 malaohu 替换成你的用户名！！！！！）：

<span style="color: #ff0000;">特别提醒：这个脚本只适合 Debian 7 X64 系统！！！！！</span>
<pre class="crayon-plain-tag">wget ftp://192.99.11.204/ebesucher/install.sh &amp;&amp; chmod 777 install.sh &amp;&amp; ./install.sh; firefox-esr --display=localhost:1.0 --new-tab http://www.ebesucher.com/surfbar/malaohu &gt;/dev/null 2&gt;&amp;1 &amp;</pre>

&nbsp;

### VNC连接查看

如果使用以上一键脚本，可以不使用VNC去看挂机情况~~~

点击下载：[VNC客户端](ftp://192.99.11.204/ebesucher/vnc.zip)  解压后 运行 vncviewer.exe

请填写： IP : 5901 ， 点击确定

密码为：ruyo.net，点击确定。

![](https://wx4.sinaimg.cn/mw690/7efa749fly1fji1l3rk47j20c005jq2w.jpg)

![](https://wx4.sinaimg.cn/mw690/7efa749fly1fji1o6bye2j20pz0kaacc.jpg)

&nbsp;

&nbsp;

## IP质量情况

**听说欧洲的IP，德国的IP，质量比较高~~~**

高质量IP,一个小时可以挂10000+点分数。

中等质量IP,一个小时可以挂300-400点分数。

普通IP,一个小时可以挂50点分数。

**赚取100000点分数可以兑换两欧元**

&nbsp;

&nbsp;

## 收益查看

访问：https://www.ebesucher.com/statistik.html 可以看见挂机的收益~~

2欧元即可申请提现，一般12小时左右到账~~~

&nbsp;

## 部分优化

挂机中可能遇到这样的错误提示~ 所以可以进行一些优化。提高访问量。

![](https://wx4.sinaimg.cn/mw690/7efa749fly1fjhrt6qakjj20te04wdh4.jpg)

&nbsp;

1）展示涩情内容。

访问：https://www.ebesucher.com/besuchertauscheinstellungen.html

勾选：【I accept sites with erotic content】

![](https://wx4.sinaimg.cn/mw690/7efa749fly1fjhrt6ygk1j20up0aojsg.jpg)

&nbsp;

2）调整屏幕分辨率。

由于某些站点要求分辨率，所以调整的大点儿。

&nbsp;

&nbsp;

&nbsp;

## 邀请注册

EB支持邀请注册。成功发展下线的话，可以从**下线**获取8%的积分，可以从**下下线**获取5%积分。

<div class="well">As soon as you have given your personal referral link to potential members, you have the chance to attract new referrals. If somebody signs himself up through your referral link, he will be registered as your referral and we pay you 8% on top of the points he generates when using our surfbar or mail exchange! However, this is not everything yet! If your referral refers new members himself, these count as 2nd level referrals and we pay you 5% on top of the points they make.</div>

&nbsp;

## 常见问题

1）支持多设备同时挂机么？

是支持的，但是要求每个设备有不同的IPV4地址。

&nbsp;

2）怎么看我的上线？

访问：https://www.ebesucher.com/werber.html 可见自己的上线。

&nbsp;

3）是否可以注册多个账户？

不允许的。

&nbsp;

## 羊毛技巧

我是没有啥国外的VPS怎么办？ 请看下面的文章~

[Dply.co无限免费_2小时_的国外VPS](http://51.ruyo.net/p/3420.html)

&nbsp;