This work hexo-theme-Anatole is forked from [farbox-theme-Anatole](https://github.com/hi-caicai/farbox-theme-Anatole). Features: two-column, responsive, clean, light, and comfortable.

此主题系 Farbox 主题 [Anatole](https://github.com/hi-caicai/farbox-theme-Anatole) 在 Hexo 平台上的移植版本。主题特色：双栏、响应式设计、纯净、轻巧、观感舒适。

Please click [here](https://github.com/Ben02/hexo-theme-Anatole/wiki) for more information about setup and usage.

请移步到 [此处](https://github.com/Ben02/hexo-theme-Anatole/wiki) 查看有关安装和配置的文档。

I am convinced that a basic rule to coordinate a theme is to respect the original one, which means the coordinated one shouldn't be altered at will. Consequensely, hexo-theme-Anatole will only update in some functional needs. If you are willing to change some style of the theme, for example, to add something to the sidebar or to reset the layout, you can DIY. Additionally, I really appreciate it if you contact me and make a commision.

移植主题的一个原则就是尊重原主题，不根据自己的意志篡改主题样式，因此本主题的更新仅进行功能上的维护。如果你有特别的需求例如增加侧边栏内容、修改版式等，可以自己动手，也可以向我发起付费修改的委托，感激不尽。

![](http://labcdn.qiniudn.com/anatole/QQ%E6%88%AA%E5%9B%BE20170113193419.png)

![](http://labcdn.qiniudn.com/anatole/QQ%E6%88%AA%E5%9B%BE20170114145625.png)
